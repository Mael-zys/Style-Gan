# Copyright (c) 2019, NVIDIA CORPORATION. All rights reserved.
#
# This work is licensed under the Creative Commons Attribution-NonCommercial
# 4.0 International License. To view a copy of this license, visit
# http://creativecommons.org/licenses/by-nc/4.0/ or send a letter to
# Creative Commons, PO Box 1866, Mountain View, CA 94042, USA.

"""Minimal script for reproducing the figures of the StyleGAN paper using pre-trained generators."""

import os
import pickle
import numpy as np
import PIL.Image
import dnnlib
import dnnlib.tflib as tflib
import config

#----------------------------------------------------------------------------
# Helpers for loading and using pre-trained generators.

url_ffhq        = 'https://drive.google.com/uc?id=1ILhx8BzGWRtb-xcH-oGA8nSvWBw07yL9' # karras2019stylegan-ffhq-1024x1024.pkl
url_celebahq    = 'https://drive.google.com/uc?id=180V6lXUkzypZOYw_Xw7UCS1ky5DP0H3C' # karras2019stylegan-celebahq-1024x1024.pkl
url_bedrooms    = 'https://drive.google.com/uc?id=1RD9wLUenO9ysOotUhGejBxsF9viN2mD6' # karras2019stylegan-bedrooms-256x256.pkl
url_cars        = 'https://drive.google.com/uc?id=1052ZBXM4FlQ1njahLcca0Wvd5g7VdH4E' # karras2019stylegan-cars-512x384.pkl
url_cats        = 'https://drive.google.com/uc?id=135mudBe7WcGuqp2-GbdYvTH7uyGV87qQ' # karras2019stylegan-cats-256x256.pkl

synthesis_kwargs = dict(output_transform=dict(func=tflib.convert_images_to_uint8, nchw_to_nhwc=True), minibatch_size=8)

_Gs_cache = dict()

def load_Gs(url):
    if url not in _Gs_cache:
        with dnnlib.util.open_url(url, cache_dir=config.cache_dir) as f:
            _G, _D, Gs = pickle.load(f)
        _Gs_cache[url] = Gs
    return _Gs_cache[url]

#----------------------------------------------------------------------------
# Figure 1: age

def draw_style_age_figure(png, Gs, w, h, src_seeds, dst_seeds, style_ranges):
    print(png)
    src_latents = np.stack(np.random.RandomState(seed).randn(Gs.input_shape[1]) for seed in src_seeds)

    alpha_list = np.linspace(-3.0, 3.0, num=61, endpoint=True)

    age_boundary = np.load("./stylegan_ffhq_age_w_boundary.npy")
    
    for alpha in alpha_list:
      src_dlatents = Gs.components.mapping.run(src_latents, None) # [seed, layer, component]

      src_dlatents_temp = src_dlatents + alpha*age_boundary
      
      src_images = Gs.components.synthesis.run(src_dlatents_temp, randomize_noise=False, **synthesis_kwargs)
      canvas=PIL.Image.new('RGB',(w*(len(src_seeds)),h*(len(dst_seeds))),'white')
      for col, src_image in enumerate(list(src_images)):
        canvas.paste(PIL.Image.fromarray(src_image,'RGB'),((col)*w,0))
      canvas.save(png+str(alpha)+'.png')

# Figure 2: glass

def draw_style_glass_figure(png, Gs, w, h, src_seeds, dst_seeds, style_ranges):
    print(png)
    src_latents = np.stack(np.random.RandomState(seed).randn(Gs.input_shape[1]) for seed in src_seeds)

    alpha_list = np.linspace(-2.0, 0, num=201, endpoint=True)

    age_boundary = np.load("./stylegan_ffhq_eyeglasses_w_boundary.npy")
    
    for alpha in alpha_list:
      src_dlatents = Gs.components.mapping.run(src_latents, None) # [seed, layer, component]

      src_dlatents_temp = src_dlatents + alpha*age_boundary
      
      src_images = Gs.components.synthesis.run(src_dlatents_temp, randomize_noise=False, **synthesis_kwargs)
      canvas=PIL.Image.new('RGB',(w*(len(src_seeds)),h*(len(dst_seeds))),'white')
      for col, src_image in enumerate(list(src_images)):
        canvas.paste(PIL.Image.fromarray(src_image,'RGB'),((col)*w,0))
      canvas.save(png+str(alpha)+'.png')

# Figure 3: male

def draw_style_male_figure(png, Gs, w, h, src_seeds, dst_seeds, style_ranges):
    print(png)
    src_latents = np.stack(np.random.RandomState(seed).randn(Gs.input_shape[1]) for seed in src_seeds)

    alpha_list = np.linspace(-3.0, 3.0, num=31, endpoint=True)

    age_boundary = np.load("./stylegan_ffhq_gender_w_boundary.npy")
    
    for alpha in alpha_list:
      src_dlatents = Gs.components.mapping.run(src_latents, None) # [seed, layer, component]

      src_dlatents_temp = src_dlatents + alpha*age_boundary
      
      src_images = Gs.components.synthesis.run(src_dlatents_temp, randomize_noise=False, **synthesis_kwargs)
      canvas=PIL.Image.new('RGB',(w*(len(src_seeds)),h*(len(dst_seeds))),'white')
      for col, src_image in enumerate(list(src_images)):
        canvas.paste(PIL.Image.fromarray(src_image,'RGB'),((col)*w,0))
      canvas.save(png+str(alpha)+'.png')

# Figure 4: smile

def draw_style_smile_figure(png, Gs, w, h, src_seeds, dst_seeds, style_ranges):
    print(png)
    src_latents = np.stack(np.random.RandomState(seed).randn(Gs.input_shape[1]) for seed in src_seeds)

    alpha_list = np.linspace(-3.0, 3.0, num=31, endpoint=True)

    age_boundary = np.load("./stylegan_ffhq_smile_w_boundary.npy")
    
    for alpha in alpha_list:
      src_dlatents = Gs.components.mapping.run(src_latents, None) # [seed, layer, component]

      src_dlatents_temp = src_dlatents + alpha*age_boundary
      
      src_images = Gs.components.synthesis.run(src_dlatents_temp, randomize_noise=False, **synthesis_kwargs)
      canvas=PIL.Image.new('RGB',(w*(len(src_seeds)),h*(len(dst_seeds))),'white')
      for col, src_image in enumerate(list(src_images)):
        canvas.paste(PIL.Image.fromarray(src_image,'RGB'),((col)*w,0))
      canvas.save(png+str(alpha)+'.png')

# interpolation
def draw_interpolation_figure(png, Gs, w, h, src_seeds, dst_seeds, style_ranges):
    print(png)
    src_latents = np.stack(np.random.RandomState(seed).randn(Gs.input_shape[1]) for seed in src_seeds)
    dst_latents = np.stack(np.random.RandomState(seed).randn(Gs.input_shape[1]) for seed in dst_seeds)
    
    alpha_list = np.linspace(0, 1.0, num=21, endpoint=True)
    
    for alpha in alpha_list:
      src_dlatents = Gs.components.mapping.run(src_latents, None) # [seed, layer, component]
      dst_dlatents = Gs.components.mapping.run(dst_latents, None) # [seed, layer, component]

      src_dlatents_temp = (1-alpha)*src_dlatents + alpha*dst_dlatents
      
      src_images = Gs.components.synthesis.run(src_dlatents_temp, randomize_noise=False, **synthesis_kwargs)

      canvas=PIL.Image.new('RGB',(w*(len(src_seeds)),h*(len(dst_seeds))),'white')
      for col, src_image in enumerate(list(src_images)):
        canvas.paste(PIL.Image.fromarray(src_image,'RGB'),((col)*w,0))
      canvas.save(png+str(alpha)+'.png')


#----------------------------------------------------------------------------
# Main program.

def main():
    tflib.init_tf()
    os.makedirs(config.result_dir, exist_ok=True)
    # draw_style_mixing_figure(os.path.join(config.result_dir, 'figure03-style-mixing.png'), load_Gs(url_ffhq), w=1024, h=1024, src_seeds=[639,701,687,615,2268], dst_seeds=[888,829,1898,1733,1614,845], style_ranges=[range(0,4)]*3+[range(4,8)]*2+[range(8,18)])
    draw_style_age_figure(os.path.join(config.result_dir, 'age'), load_Gs(url_ffhq), w=1024, h=1024, src_seeds=[2268], dst_seeds=[888], style_ranges=[range(0,4)]*3+[range(4,8)]*2+[range(8,18)])
    draw_style_glass_figure(os.path.join(config.result_dir, 'glass'), load_Gs(url_ffhq), w=1024, h=1024, src_seeds=[639], dst_seeds=[888], style_ranges=[range(0,4)]*3+[range(4,8)]*2+[range(8,18)])
    draw_style_male_figure(os.path.join(config.result_dir, 'male'), load_Gs(url_ffhq), w=1024, h=1024, src_seeds=[615], dst_seeds=[888], style_ranges=[range(0,4)]*3+[range(4,8)]*2+[range(8,18)])
    draw_style_smile_figure(os.path.join(config.result_dir, 'smile'), load_Gs(url_ffhq), w=1024, h=1024, src_seeds=[639], dst_seeds=[888], style_ranges=[range(0,4)]*3+[range(4,8)]*2+[range(8,18)])
    draw_interpolation_figure(os.path.join(config.result_dir, 'interpolation'), load_Gs(url_ffhq), w=1024, h=1024, src_seeds=[615], dst_seeds=[1614], style_ranges=[range(0,4)]*3+[range(4,8)]*2+[range(8,18)])
#----------------------------------------------------------------------------

if __name__ == "__main__":
    main()

#----------------------------------------------------------------------------
